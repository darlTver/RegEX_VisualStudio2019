﻿/*
Name: 
Date: June 25, 2022
Description: Regular Expressions
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace RegEX2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you really want to quit?", "Regex Darlene", MessageBoxButtons.OKCancel).ToString() == "OK")
                this.Close();
        }

        // to check email address
        private void button1_Click(object sender, EventArgs e)
        {
            // \w = [a-zA-Z0-9_] ; size 10-45 chars.
            Regex objRegEx = new Regex(@"^([\w\-\.]){3,19}@([a-zA-Z]){3,19}\.([a-z]){2,5}$"); 
            
            if (objRegEx.IsMatch(textBox1.Text.Trim()) == true)
            {
                MessageBox.Show("E-mail address is ok.");
            }
            else
            {
                MessageBox.Show("Wrong e-mail address. \n Use Abc@Abc.mnp where Abc is between3 to 19 chars \n and mnp is between 2 and 5 chars");
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        // delete extra spaces
        private void button2_Click(object sender, EventArgs e)
        {
            Regex objRegEx = new Regex(@"(\s)");
            textBox1.Text = objRegEx.Replace(textBox1.Text.Trim(), "");
        }

        // validate postal code
        private void button3_Click(object sender, EventArgs e)
        {
            //Regex objRegEx = new Regex(@"^([\w\-]){3}\-([\w\-]){3}$");

            Regex objRegEx = new Regex(@"^([a-z-A-Z][0-9][a-z-A-Z])\-([0-9][a-z-A-Z][0-9])$");

            if (objRegEx.IsMatch(textBox1.Text.Trim()) == true)
            {
                MessageBox.Show("Postal code is ok.");
            }
            else
            {
                MessageBox.Show("Wrong format! Try again.");
            }
        }

        // delete letters a, b, c, d
        private void button4_Click(object sender, EventArgs e)
        {            
            Regex objRegEx = new Regex(@"([a-b-c-d-A-B-C-D])");
            textBox1.Text = objRegEx.Replace(textBox1.Text.Trim(), "");
        }

        // create an array of words
        private void button5_Click(object sender, EventArgs e)
        {
            Regex objRegEx = new Regex(@"^[\s]*"); // + more spaces; * zero 1 or many
            string[] strArr = objRegEx.Split(textBox1.Text.Trim());
            string textToPrint = "";
            for(int i =0; i < strArr.Length; i++)
            {
                textToPrint += strArr[i] + "\n";
            }
            if (textToPrint.Length > 0) MessageBox.Show(textToPrint);
         //   if (strArr.Length > 0) MessageBox.Show(textToPrint);

        }
    }
}
